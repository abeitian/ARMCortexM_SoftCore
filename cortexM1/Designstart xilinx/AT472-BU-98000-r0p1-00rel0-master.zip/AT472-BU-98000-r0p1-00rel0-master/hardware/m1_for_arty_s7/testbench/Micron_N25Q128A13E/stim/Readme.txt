//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-
//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-
//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-
//
//  N25Q128A13E
//
//  Verilog Behavioral Model
//  Version 1.2
//
//  Copyright (c) 2013 Micron Inc.
//
//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-
//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-
//-MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON--MICRON-

The files in this folder contain NCSIM transactions,
that can be visualized into the waveform window.

Trasactions visualization is useful to increase
waveform readability.


If you are using NCSIM simulator,
the following transactions-fiber can be visualized:

- Testbench.tasks."Tasks fiber" (compile top/Transactions/Stimtasks.v instead of top/Stimtasks.v)

- Testbench.stim."Test fiber" (compile stimuli files contained in ./stim/Transactions/ directory 
                               instead of ./stim/directory)
